Configuration TestConfig3 {

    Node 'localhost'
    {
        WindowsFeature WebServerRole
        {
            Name = "Web-Server"
            Ensure = "Present"
        }
    }
}